import { Box, Button, Card, FormControl, IconButton, Input, InputAdornment, InputLabel, TextField, Typography } from '@mui/material'
import React from 'react'
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
const Register = () => {

  // For Password

  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };


  return (
    <>
    <Box className="regSec display">
      <Card className='regCard display-c' sx={{justifyContent :"space-around", boxShadow:"none"}}>
        <Typography variant='h4'>Sign Up</Typography>
        <Box className="regForm display-c" type="form" sx={{backgroundColor:"white"}}>
        <TextField
          id="standard-required"
          label="Name"
          defaultValue=""
          placeholder='Enter Name Here'
          variant="standard"
          fullWidth    
          inputProps={{style: {fontSize: 15}}} // font size of input text
          InputLabelProps={{style: {fontSize: 16}}} // font size of input label 
        />
        <TextField
          id="standard-required"
          label="Email"
          defaultValue=""
          variant="standard"
          placeholder='Enter Email Here'
          fullWidth   
          inputProps={{style: {fontSize: 15}}} // font size of input text
          InputLabelProps={{style: {fontSize: 16}}} // font size of input label           
        />
         <FormControl fullWidth sx={{ m: 1 }} variant="standard" 
         >
          <InputLabel htmlFor="standard-adornment-password" style={{fontSize:"1.7rem"}}
          >Password</InputLabel>
          <Input
           inputProps={{style: {fontSize: 15}}} // font size of input text
            id="standard-adornment-password"
            type={showPassword ? 'text' : 'password'}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
         <FormControl fullWidth sx={{ m: 1 }} variant="standard">
          <InputLabel 
          
          htmlFor="standard-adornment-password" style={{fontSize:"1.7rem"}}>Confirm Password</InputLabel>
          <Input
           inputProps={{style: {fontSize: 15}}} // font size of input text
            id="standard-adornment-password"
            type={showPassword ? 'text' : 'password'}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
        <Button variant='outlined' sx={{width : "100%" , padding:"1rem" , marginTop:"2rem"}}>Register</Button>
        <p>I have already Signup here,  <a href="">Please Login</a></p>
        </Box>
      </Card>
    </Box>
    </>
  )
}

export default Register
