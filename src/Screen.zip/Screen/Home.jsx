import { Box, Button, Typography } from '@mui/material'
import React from 'react'

const Home = () => {
  return (
    <Box>
      <Box className="homeBg">
        <Box className="homeHeading" sx={{flexDirection : "column"}}>
          <Typography variant='h2' align='center'>
            Welcome To The Support-Desk
          </Typography>
          <Box sx={{width:"40%",height:"40%" , display:"flex", alignItems:"center", justifyContent:"space-around"}}>
            <Button variant='contained' color='warning' sx={{paddingInline : "2rem", paddingBlock :"1rem", fontSize:"1.3rem"}}>Create Ticket</Button>
            <Button variant='contained' color='secondary' sx={{paddingInline : "2rem", paddingBlock :"1rem", fontSize:"1.3rem"}}>All Ticket</Button>
          </Box>
        </Box>
      </Box>
    </Box>
  )
}

export default Home
