import { Box, Card,FormControl, IconButton, Input, InputAdornment, InputLabel, TextField, Typography, Button } from '@mui/material'
import React from 'react'
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import LoginUserLogo from "../assets/Img/LoginUserLogo.png"
const Login = () => {
  const [showPassword, setShowPassword] = React.useState(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };


  return (
    <>
    <Box className="loginSec display">
    <Card className='loginCard display-c' sx={{justifyContent :"space-around", boxShadow:"none"}}>
      <Box className="display loginLogo" sx={{width:"30%", height:"30%"}}>
        <img src={LoginUserLogo} alt="" />
      </Box>
        <Typography variant='h4'>Login</Typography>
        <Box className="loginForm display-c" type="form" sx={{backgroundColor:"white"}}>
        <TextField
          id="standard-required"
          label="Email"
          defaultValue=""
          variant="standard"
          placeholder='Enter Email Here'
          fullWidth   
          inputProps={{style: {fontSize: 15}}} // font size of input text
          InputLabelProps={{style: {fontSize: 16}}} // font size of input label           
        />
         <FormControl fullWidth sx={{ m: 1 }} variant="standard" 
         >
          <InputLabel htmlFor="standard-adornment-password" style={{fontSize:"1.7rem"}}
          >Password</InputLabel>
          <Input
           inputProps={{style: {fontSize: 15}}} // font size of input text
            id="standard-adornment-password"
            type={showPassword ? 'text' : 'password'}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={handleClickShowPassword}
                  onMouseDown={handleMouseDownPassword}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }
          />
        </FormControl>
        
        <Button variant='outlined' sx={{width : "100%" , padding:"1rem" , marginTop:"2rem"}} style={{fontSize:"1.4rem"}}>Login</Button>
        <span className='display-c' style={{justifyContent:"space-between", width:"100%", height:"5rem" , marginTop:"2rem"}}>
        <a href="">Forget Password</a>
        <p>No Account<a href=""  style={{marginLeft:"1rem"}}>Sign Up</a></p>
        </span>
        </Box>
      </Card>
    </Box>
    </>
  )
}

export default Login
